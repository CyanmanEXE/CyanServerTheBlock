local package_id = "com.Dawn.Shademan"
local character_id = "com.Dawn.Enemy.Shademan"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Shademan")
    package:set_description("Don't underestimate the Darkloids!")
    package:set_speed(1)
    package:set_attack(40)
    -- Match the highest built-in character rank (SP = 1200 HP).
    -- ezencounters can then apply persistent current HP up to this capacity.
    package:set_health(1200)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."BG.png"
    local animPath = _modpath.."BG.animation"
    mob:set_background(texPath, animPath, 0.5, -0.3)
    mob:stream_music(_modpath.."song.mid", 0, 0)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end