print("[EZDBG][CLIENT][CHAR_FILE_LOADED] com_louise_Quaker.zip:Shaker/entry.lua")
local shared_package_init = include("../Quaker/character.lua")
local character_id = "com.louise.enemy."
function package_init(character, ezencounters_data)
    print("[EZDBG][CLIENT][PACKAGE_INIT_BEGIN] com_louise_Quaker.zip:Shaker/entry.lua")
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.louise.enemy.Shaker"}
            local aliases = {["Shaker"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Shaker",
        hp = 120,
        damage = 100,
        palette = _folderpath .. "palette.png",
        height = 44,
        frames_between_actions = 78,
        shockwave_anim = "shockwave_fast.animation",
        cascade_frame = 3
    }

    shared_package_init(character, character_info)
end
