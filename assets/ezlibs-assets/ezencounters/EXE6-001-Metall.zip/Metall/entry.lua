local shared_package_init = include("../Metall/character.lua")

function package_init(character, ezencounters_data)
    -- EZENCOUNTERS MAX-HP SUPPORT v11 --
    do
        local payload = ezencounters_data
        if type(payload) == "table" then
            local ids = {"com.OFC.char.EXE6-001-Metall"}
            local aliases = {["Mettaur"]=true}
            local requested = nil
            local conflict = false
            local maxima = payload.__ezencounters_hp_max_by_package
            if type(maxima) == "table" then
                for _, id in ipairs(ids) do
                    local value = tonumber(maxima[id])
                    if value ~= nil and value > 0 and value == value and value ~= math.huge then
                        if requested ~= nil and requested ~= value then conflict = true end
                        requested = value
                    end
                end
            end
            -- Some engine builds pass an independent copy of encounter data
            -- to the Character package. Resolve from original enemy entries
            -- as well, rather than depending on a mutation in package_build.
            if requested == nil and type(payload.enemies) == "table" then
                for _, enemy in ipairs(payload.enemies) do
                    if type(enemy) == "table" and aliases[enemy.name] then
                        local value = tonumber(enemy.max_hp)
                        if value == nil and #payload.enemies == 1 then
                            value = tonumber(payload.max_hp)
                        end
                        if value ~= nil and value > 0 and value == value and value ~= math.huge then
                            if requested ~= nil and requested ~= value then conflict = true end
                            requested = value
                        end
                    end
                end
            end
            if not conflict and requested ~= nil and requested == math.floor(requested) then
                print("[ezencounters hp] INITIAL MAX HP", ids[1], requested)
                character:set_health(requested)
            end
        end
    end

    local character_info = {
        name = "Metall",
        hp = 40,
        damage = 10,
        damage_shockwave = 10,
        cascade_frame = 5,
        move_delay = 37, -- old: 38
        shockwave_state = "0",
        shockwave_frames = 22,
        can_guard = true,
        replacement_panel = nil
    }
    if character:get_rank() == Rank.V1 then
        character_info.can_guard = false
    end
    if character:get_rank() == Rank.V2 then
        character_info.damage = 20
        character_info.damage_shockwave = 30
        character_info.cascade_frame = 5
        character_info.hp = 80
        character_info.move_delay = 31 -- old: 32
        character_info.shockwave_state = "1"
        character_info.shockwave_frames = 16
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 40
        character_info.damage_shockwave = 50
        character_info.hp = 120
        character_info.cascade_frame = 4
        character_info.move_delay = 25 -- old: 26
        character_info.shockwave_state = "1"
        character_info.shockwave_frames = 11
    elseif character:get_rank() == Rank.SP then
        character_info.damage = 60
        character_info.damage_shockwave = 70
        character_info.hp = 160
        character_info.cascade_frame = 3
        character_info.move_delay = 19 -- old: 24
        character_info.shockwave_state = "2"
        character_info.shockwave_frames = 6
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 40
        character_info.damage_shockwave = 50
        character_info.hp = 120
        character_info.cascade_frame = 5
        character_info.move_delay = 25 -- old: 26
        character_info.shockwave_state = "1"
        character_info.shockwave_frames = 16
        character_info.replacement_panel = TileState.Cracked
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 80
        character_info.damage_shockwave = 100
        character_info.hp = 180
        character_info.cascade_frame = 3
        character_info.move_delay = 19 -- old: 24
        character_info.shockwave_state = "2"
        character_info.shockwave_frames = 6
        character_info.replacement_panel = TileState.Poison
    end
    shared_package_init(character,character_info)
end