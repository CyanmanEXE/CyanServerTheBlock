-- Includes
---@type BattleHelper
local battle_helpers = include("battle_helpers.lua")
---@type Blade
local spells = include("spells.lua")
local lifesword = include("lifesword/entry.lua")
local yoyo = include("yoyo/entry.lua")

-- Animations and Textures
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
local TELEPORT_TEXTURE = Engine.load_texture(_folderpath .. "teleport.png")
local TELEPORT_ANIM = _folderpath .. "teleport.animation"

local cut_fx = Engine.load_audio(_folderpath .. "cut_fx.ogg")

--possible states for character
local states = { DEFAULT = 1, ATTACK = 2, SCISSORS = 3 }
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    if (self:get_rank() == Rank.NM) then
        self.animation:load(_folderpath .. "battleNM.animation")
    else
        self.animation:load(base_animation_path)
    end

    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.damage = (character_info.damage)
    self.scissor_max = character_info.scissor_max
    self.scissor_damage = character_info.scissor_damage
    self.boomerang_damage = character_info.boomerang_damage
    self.cut_damage = character_info.cut_damage
    self.scissors = 0
    --
    self.frames_between_actions = character_info.frames_between_actions
    self:set_element(Element.Sword)
    self:register_status_callback(Hit.Flinch, function()
        local anim = self:get_animation()
        anim:set_state("PLAYER_HIT")
        anim:set_playback(Playback.Once)
        self.frame_counter = 0
    end)
    --Other Setup
    self:set_explosion_behavior(4, 1, false)
    -- entity will spawn with this animation.
    self.animation:set_state("PLAYER_IDLE")
    self.frame_counter = 0
    self.started = false
    --This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.move_counter = 0




    -- actions for states

    -- Code that runs in the default state
    ---@param frame number
    self.action_default = function(frame)
        if (frame == self.frames_between_actions) then
            self.move_counter = self.move_counter + 1
            local anim = self:get_animation()
            anim:set_state("WARP_OUT")
            battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), TELEPORT_TEXTURE, TELEPORT_ANIM,
                "MEDIUM_TELEPORT_FROM",
                0, 0)
            anim:on_complete(function()
                battle_helpers.move_random_adjacent(self)
                anim:set_state("WARP_IN")
                anim:on_complete(function()
                    if (self.move_counter < 5) then
                        if (self.move_counter % 2 == 0 and self.scissors < self.scissor_max) then
                            self.set_state(states.SCISSORS)
                        else
                            self.set_state(states.DEFAULT)
                        end
                    else
                        self.set_state(states.ATTACK)
                        self.move_counter = 0
                    end
                end)
            end)
        end
    end

    --- Code that runs in the attack state.
    ---@param frame number
    self.action_attack = function(frame)
        local anim = self:get_animation()
        local targetChar = battle_helpers.face_target(self)
        if not targetChar then
            if frame == self.frames_between_actions then self.set_state(states.DEFAULT) end
            return
        end
        if (frame == self.frames_between_actions) then
            anim:set_state("WARP_OUT")
            battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), TELEPORT_TEXTURE, TELEPORT_ANIM,
                "MEDIUM_TELEPORT_FROM",
                0, 0)
            anim:on_complete(function()
                anim:set_state("WARP_IN")

                local moveTile = battle_helpers.move_in_front_of_enemy(self, targetChar)
                self.cut = moveTile ~= nil and
                    moveTile:y() == targetChar:get_current_tile():y() and
                    math.abs(moveTile:x() - targetChar:get_current_tile():x()) == 1
            end)

        end
        if (frame == self.frames_between_actions + 30) then
            battle_helpers.face_target(self)
            if (self.cut) then
                local props = Battle.CardProperties:new()
                props.damage = self.cut_damage
                cutman_action = cutman_cut(self, props)
            else
                if (self:get_rank() == Rank.NM) then
                    self.animation:set_state("PLAYER_IDLE")
                    local r = math.random(1, 8)
                    if (r < 4) then
                        spells.throw(self, self.boomerang_damage)
                    elseif (r < 7) then
                        local action = yoyo.card_create_action(self)
                        self:card_action_event(action, ActionOrder.Involuntary)
                    else
                        local action = lifesword.card_create_action(self)
                        self:card_action_event(action, ActionOrder.Involuntary)
                    end
                else
                    spells.throw(self, self.boomerang_damage)
                end
            end
        elseif (frame == self.frames_between_actions + 80) then
            self.set_state(states.DEFAULT)
        end
    end

    self.action_scissor = function(frame)
        if (frame == 1) then
            self.animation:set_state("POINT")
            self.animation:on_frame(2, function()
                if (self.scissors < self.scissor_max) then
                    local spawn_tile = battle_helpers.choose_scissor_tile(self)
                    if spawn_tile then
                        spells.summon_scissor(self, self.scissor_damage, spawn_tile)
                        self.scissors = self.scissors + 1
                    end
                end
            end)
        elseif (frame == 30) then
            self.set_state(states.DEFAULT)
        end
    end

    cutman_cut = function(user, props)
        user.animation:set_state("PLAYER_CUT")
        local hit_props = HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Sword,
            user:get_context(),
            Drag.None
        )

        user.animation:on_frame(2, function()
            Engine.play_audio(cut_fx, AudioPriority.Highest)
            local spell = Battle.Spell.new(user:get_team())
            spell:set_hit_props(hit_props)
            local hit_tile = user:get_tile(user:get_facing(), 1)
            if not hit_tile or hit_tile:is_edge() then return end
            spell:set_facing(user:get_facing())
            user:get_field():spawn(spell, hit_tile)
            spell.frame = 0
            spell.update_func = function()
                spell.frame = spell.frame + 1
                if (spell.frame == 3) then
                    spell:get_current_tile():attack_entities(spell)
                    spell:erase()
                end
            end
        end)
        user.animation:on_complete(function()
            local anim = self:get_animation()
            anim:set_state("PLAYER_IDLE")
            user.set_state(1)
        end)
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_default, [2] = self.action_attack, [3] = self.action_scissor }
    self.update_func = function()
        if not self:is_teleporting() then battle_helpers.face_target(self) end
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.DEFAULT)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end
end

return package_init
