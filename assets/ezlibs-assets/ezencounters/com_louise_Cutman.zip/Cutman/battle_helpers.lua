--Functions for easy reuse in scripts
--Version 1.0

---@class BattleHelper
battle_helpers = {}

---comment
---@param field #reference to battlefield
---@param tile #tile to spawn the visual artifact on
---@param texture #texture to use
---@param animation_path #path to animation
---@param animation_state #state to use
---@param position_x #offsetX
---@param position_y #offsetY
function battle_helpers.spawn_visual_artifact(field, tile, texture, animation_path, animation_state, position_x,
                                              position_y)
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    anim:refresh(visual_artifact:sprite())
    field:spawn(visual_artifact, tile:x(), tile:y())
end

battle_helpers.can_move_to_func = function(tile, entity)
    if not tile or tile:is_edge() or not tile:is_walkable() or tile:get_team() ~= entity:get_team() or
        tile:is_reserved({ entity:get_id(), entity._reserver }) then
        return false
    end

    local has_character = false

    tile:find_characters(function(c)
        if c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)

    tile:find_obstacles(function(c)
        if c:get_health() > 1 and c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)

    return not has_character
end

-- This function returns a target enemy.
function battle_helpers.find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then

        return
    end
    local target_character = target_list[1]
    return target_character
end

battle_helpers.can_move_to_func_front_row = function(tile)
    if not tile:is_walkable() or tile:get_team() ~= self:get_team() or
        tile:is_reserved({ self:get_id(), self._reserver }) then
        return false
    end

    local has_character = false

    tile:find_characters(function(c)
        if c:get_id() ~= self:get_id() then
            has_character = true
        end
        return false
    end)

    if tile:get_tile(Direction.Left, 1):get_team() == self:get_team() then
        has_character = true
    end

    return not has_character
end


battle_helpers.can_move_to_func_target_enemy = function(tile)

    if not tile:is_walkable() or tile:get_team() ~= self:get_team() or
        tile:is_reserved({ self:get_id(), self._reserver }) then
        return false
    end

    local has_enemy = false
    local x = 0
    while x < 6 do
        if tile:get_tile(Direction.Left, x):is_edge() then
            return has_enemy
        end
        tile:get_tile(Direction.Left, x):find_characters(function(c)
            if c:get_id() ~= self:get_id() then
                has_enemy = true
            end
            return false
        end)
        x = x + 1
    end
    return has_enemy



end

function battle_helpers.find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

-- This function moves the character to an adjacent tile.
function battle_helpers.face_target(character)
    local target = battle_helpers.find_target(character)
    local own = character:get_current_tile()
    local opponent = target and target:get_current_tile()
    if own and opponent then
        if opponent:x() > own:x() then character:set_facing(Direction.Right)
        elseif opponent:x() < own:x() then character:set_facing(Direction.Left) end
    end
    return target
end

function battle_helpers.choose_scissor_tile(character)
    local field = character:get_field()
    local own = character:get_current_tile()
    local candidates = {}
    for x = 1, field:width() do
        for y = 1, field:height() do
            local tile = field:tile_at(x, y)
            if tile and tile ~= own and battle_helpers.can_move_to_func(tile, character) then
                candidates[#candidates + 1] = tile
            end
        end
    end
    table.sort(candidates, function(a, b)
        local ar = character:get_facing() == Direction.Right and a:x() or -a:x()
        local br = character:get_facing() == Direction.Right and b:x() or -b:x()
        if ar ~= br then return ar < br end
        return math.abs(a:y() - 2) < math.abs(b:y() - 2)
    end)
    return candidates[1]
end

function battle_helpers.move_random_adjacent(character)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local adjacent_tiles = { my_tile:get_tile(Direction.Up, 1),
        my_tile:get_tile(Direction.Down, 1),
        my_tile:get_tile(Direction.Left, 1),
        my_tile:get_tile(Direction.Right, 1)
    }
    for index, prospective_tile in ipairs(adjacent_tiles) do
        if battle_helpers.can_move_to_func(prospective_tile, character) and prospective_tile ~= character.last_tile and
            my_tile ~= prospective_tile then
            table.insert(tile_array, prospective_tile)
        end
    end
    -- Also consider other owned panels: surrounded formations have two
    -- disconnected enemy flanks, with no adjacent path between them.
    local all_owned = {}
    for x = 1, field:width() do
        for y = 1, field:height() do
            local t = field:tile_at(x, y)
            if t and t ~= my_tile and t ~= character.last_tile and
                battle_helpers.can_move_to_func(t, character) then
                all_owned[#all_owned + 1] = t
            end
        end
    end
    if #all_owned > 0 and (#tile_array == 0 or math.random(1, 3) == 1) then
        tile_array = all_owned
    end
    if #tile_array == 0 then return false end
    local destination = tile_array[math.random(1, #tile_array)]
    local previous = my_tile
    return character:teleport(destination, ActionOrder.Immediate, function()
        character.last_tile = previous
        battle_helpers.face_target(character)
    end)
end

--This function moves the character towards a position.
function battle_helpers.move_towards_row(character, row)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local target_tile = nil

    -- Check which tile the bunny needs to move towards to reach megaman.
    if (row < my_tile:y()) then
        target_tile = my_tile:get_tile(Direction.Up, 1)
    else
        target_tile = my_tile:get_tile(Direction.Down, 1)
    end

    if battle_helpers.can_move_to_func(target_tile, character) then
        moved = character:teleport(target_tile, ActionOrder.Immediate)
        return moved
    else
        --if cant move to prospective tile, move to a random tile left or right.
        local alternate_tiles = { my_tile:get_tile(Direction.Left, 1),
            my_tile:get_tile(Direction.Right, 1) }

        for index, prospective_tile in ipairs(alternate_tiles) do
            if battle_helpers.can_move_to_func(prospective_tile, character) and
                my_tile ~= prospective_tile then
                table.insert(tile_array, prospective_tile)
            end
        end
        if #tile_array == 0 then return false end
        target_tile = tile_array[math.random(1, #tile_array)]
        if target_tile then
            moved = character:teleport(target_tile, ActionOrder.Immediate)
        end
        return moved
    end
end

--- Moves character in front of enemy as close as possible.
---@param character any
---@param enemy_char any
---@return Tile
function battle_helpers.move_in_front_of_enemy(character)
    local enemy_char = battle_helpers.face_target(character)
    if not enemy_char then return nil end
    local enemy_tile = enemy_char:get_current_tile()
    if not enemy_tile then return nil end
    local candidates = {}
    local field = character:get_field()
    for x = 1, field:width() do
        for y = 1, field:height() do
            local tile = field:tile_at(x, y)
            if tile and battle_helpers.can_move_to_func(tile, character) then
                candidates[#candidates + 1] = tile
            end
        end
    end
    table.sort(candidates, function(a, b)
        local da = math.abs(a:x() - enemy_tile:x()) * 2 + math.abs(a:y() - enemy_tile:y())
        local db = math.abs(b:x() - enemy_tile:x()) * 2 + math.abs(b:y() - enemy_tile:y())
        return da < db
    end)
    for _, tile in ipairs(candidates) do
        if character:teleport(tile, ActionOrder.Immediate, function()
            battle_helpers.face_target(character)
        end) then
            return tile
        end
    end
    return nil
end

function Tiletostring(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

return battle_helpers
