local package_prefix = "OFC"
local package_gid = "EXEPoN-022"
local package_name = "FireMan"

local package_id = "com."..package_prefix..".mob."..package_gid.."-"..package_name.."V1"
local character_id = "com."..package_prefix..".char."..package_gid.."-"

function package_requires_scripts()
    Engine.define_character(character_id..package_name, _modpath..package_name)
end

function package_init(package)
    print('package init for '..package_id)
    package:declare_package_id(package_id)
    package:set_name(package_name.." (EXEPoN)")
    package:set_description("Test fight with "..package_name.." from EXEPoN")
    package:set_speed(1)
    package:set_attack(30)
    package:set_health(400)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    --local texPath = _modpath.."MeiruHP.png"
    --local animPath = _modpath.."MeiruHP.animation"
    --local texPath = _modpath.."exe4-akiharaarea.png"
    --local animPath = _modpath.."exe4-akiharaarea.animation"
    local texPath = _modpath.."exepon-meirunopcnodennou.png"
    local animPath = _modpath.."exepon-meirunopcnodennou.animation"
    mob:set_background(texPath, animPath, 0.25, 0.2)
    --mob:stream_music(_modpath.."exepon-boss.ogg", 903, 38377)
    mob:stream_music(_modpath.."phantom_boss.ogg", 0, 38409)
    
    --[[
    mob:get_field():tile_at(1, 1):set_state(TileState.Lava)
    mob:get_field():tile_at(1, 3):set_state(TileState.Lava)
    mob:get_field():tile_at(3, 2):set_state(TileState.Lava)
  
    mob:get_field():tile_at(4, 2):set_state(TileState.Lava)
    mob:get_field():tile_at(6, 1):set_state(TileState.Lava)
    mob:get_field():tile_at(6, 3):set_state(TileState.Lava)
    ]]
  
    local spawner = mob:create_spawner(character_id..package_name,Rank.V1)
    spawner:spawn_at(5, 2)
end  