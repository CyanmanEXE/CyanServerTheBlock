local ring_sound = Engine.load_audio(_folderpath .. "ring.ogg")
local clap_sound = Engine.load_audio(_folderpath .. "clap.ogg")
local tent_sound = Engine.load_audio(_folderpath .. "tent.ogg")
---@type FxHelper
local fx_helper = include("fx.lua")
local attacks_sprite = Engine.load_texture(_folderpath .. "circus_attacks.png")
local attacks_anim = _folderpath .. "circus_attacks.animation"
local battle_helpers = include("battle_helpers.lua")
local character_animation = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
local states = { IDLE = 1, JUMP = 2, LAND = 3, RINGS = 4, TENT = 5 }

local hit_texture = Engine.load_texture(_folderpath .. "effect.png")
local hit_texture_anim = _folderpath .. "effect.animation"

local buster_hit_texture = Engine.load_texture(_folderpath .. "buster.png")
local buster_hit_anim = _folderpath .. "buster.animation"

local hurt_sound = Engine.load_audio(_folderpath .. "hurt.ogg")

---@class Spells
local Spells = {}

---Used by circus man to clap
---@param owner Entity
function Spells.clap(user, anim_name, y_pos)
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())
    local spell_animation = spell:get_animation()
    local target = battle_helpers.find_target(user)
    local target_tile = field:tile_at(target:get_tile():x(), y_pos)
    spell:set_hit_props(
        HitProps.new(
            user.attack_damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )

    spell:set_facing(user:get_facing())

    spell_animation:load(attacks_anim)
    spell_animation:set_state(anim_name)
    spell:set_texture(attacks_sprite)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    local do_once = true
    local delay = 20
    spell.update_func = function(self, dt)
        if (delay > 0) then
            delay = delay - 1
            if (y_pos == 3) then
                spell:get_current_tile():highlight(Highlight.Flash)
                spell:get_current_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
                spell:get_current_tile():get_tile(Direction.Up, 2):highlight(Highlight.Flash)
            end
            return
        end

        if do_once then
            spell_animation:on_frame(3, function()
                spell:get_current_tile():attack_entities(self)
            end)
            spell_animation:on_frame(4, function()
                if (y_pos == 3) then
                    spell:get_current_tile():get_tile(Direction.Up, 1):attack_entities(self)
                    Engine.play_audio(clap_sound, AudioPriority.Highest)
                end
            end)
            spell_animation:on_complete(function()

                spell:delete()

            end)
            do_once = false
        end

    end

    spell.collision_func = function(self, other)
    end
    spell.attack_func = function(self, other)
        fx_helper.create_hit_effect(spell:get_field(),
            spell:get_current_tile(), hit_texture, hit_texture_anim, "0",
            hurt_sound)
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, target_tile)
end

---Used by circus man to summon lions
---@param owner Entity
function Spells.summon_lion(user)
    local field = user:get_field()
    ---@class Spell
    local spell = Battle.Spell.new(user:get_team())
    local spell_animation = spell:get_animation()
    local target = battle_helpers.find_target(user)
    local target_tile = field:tile_at(4, target:get_tile():y())
    spell:set_hit_props(
        HitProps.new(
            user.attack_damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    spell_animation:load(attacks_anim)
    spell_animation:set_state("LION")
    spell:hide()
    spell:set_texture(attacks_sprite)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    local do_once = true
    local count_frames = 0
    spell.fire_ring = Spells.spawn_flame_ring(user, target_tile)
    Engine.play_audio(ring_sound, AudioPriority.High)
    spell.update_func = function(self, dt)
        if count_frames == 20 then
            -- 20 frames before lion shows up
            if (do_once) then
                spell:reveal()
                do_once = false
            end
            if not spell:get_current_tile():is_walkable() then
                spell.fire_ring:erase()
                spell:erase()
                return
            end


            count_frames = 0
        end

        if not (do_once) then
            local targ_tile = spell:get_current_tile():get_tile(spell:get_facing(), 1)
            spell:slide(targ_tile, frames(7), frames(0), ActionOrder.Voluntary, nil)
        end
        spell:get_current_tile():attack_entities(self)

        count_frames = count_frames + 1
    end
    spell.collision_func = function(self, other)
    end
    spell.attack_func = function(self, other)
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, target_tile)
end

---Spawns a fire ring effect at a tile.
---@param owner Entity
---@param tile Tile
---@return #the visual artifact
function Spells.spawn_flame_ring(owner, tile)
    local visual_artifact = Battle.Artifact.new()
    --visual_artifact:hide()
    visual_artifact:set_facing(owner:get_facing())
    local sprite = visual_artifact:sprite()
    sprite:set_texture(attacks_sprite)
    sprite:set_layer(-1)
    local animation = visual_artifact:get_animation()
    animation:load(attacks_anim)
    animation:set_state("FIRE_RING")
    animation:set_playback(Playback.Loop)
    local frames = 0
    animation:refresh(sprite)
    owner:get_field():spawn(visual_artifact, tile:x(), tile:y())
    return visual_artifact
end

function Spells.tent_create(self)
    local enemies_filter = function(character)
        return character:get_team() ~= self:get_team()
    end
    --- the main timefreeze action
    local tent_artifact = Spells.create_tent_artifact(self.tent_target, self)
    ---@class Entity
    local circus_man = self
    local timefreeze_action = function()
        local target_character = self.tent_target:find_characters(enemies_filter)
        if (#target_character == 1) then
            local action = Battle.CardAction.new(self, "TENT_ACTION")
            tent_artifact:get_animation():set_state("TENT_CLOSE")
            local frame_count = 0
            local do_once = true
            action:set_lockout(make_sequence_lockout())
            action.execute_func = function(self, user)
                local step = Battle.Step.new()
                frame_count = frame_count + 1
                Engine.play_audio(tent_sound, AudioPriority.High)
                user:shake_camera(10, 0.7)
                step.update_func = function()
                    frame_count = frame_count + 1
                    --wait for tent to close
                    if (frame_count < 25) then
                        return
                    end
                    if (frame_count == 25) then
                        tent_artifact:get_animation():set_state("TENT_ATTACK")
                        tent_artifact:get_animation():set_playback(Playback.Loop)
                    end
                    if (frame_count < 210) then
                        if (frame_count % 8 == 0) then

                            Spells.circus_tent_hit(circus_man, tent_artifact.target)
                        end
                    else
                        if (do_once) then

                            tent_artifact:get_animation():set_state("TENT_OPEN")
                            tent_artifact:get_animation():on_complete(function()
                                tent_artifact:get_animation():set_state("TENT_DISAPPEAR")
                                tent_artifact:get_animation():on_complete(function()
                                    tent_artifact:erase()
                                    step:complete_step()
                                    circus_man:set_offset(0, 0)
                                    circus_man.left_hand:set_offset(0, 0);
                                    circus_man.right_hand:set_offset(0, 0);
                                    circus_man:show_shadow(true)
                                    circus_man:reveal()
                                    circus_man.animation:set_state("END_TENT")
                                    circus_man.animation:on_complete(function()
                                        circus_man.set_state(states.IDLE)
                                    end)
                                end)
                            end)
                            do_once = false
                        end

                    end
                end
                action:add_step(step)
            end
            action.action_end_func = function(self)
            end
            local meta = action:copy_metadata()
            meta.time_freeze = true
            meta.skip_time_freeze_intro = true
            action:set_metadata(meta)
            self:card_action_event(action, ActionOrder.Voluntary)
        else --no timefreeze, no target.
            tent_artifact:get_animation():set_state("TENT_DISAPPEAR")
            tent_artifact:get_animation():on_complete(function()
                tent_artifact:erase()
                self.set_state(states.IDLE)
                circus_man:set_offset(0, 0)
                circus_man.left_hand:set_offset(0, 0);
                circus_man.right_hand:set_offset(0, 0);
                circus_man:show_shadow(true)
                circus_man:reveal()
                self.animation:set_state("END_TENT")
                self.animation:on_complete(function()
                    self.set_state(states.IDLE)
                end)
            end)
        end
    end
    self.tent = tent_artifact
    tent_artifact.target = self.tent_target
    tent_artifact:get_animation():on_complete(timefreeze_action)

end

---Tent artifact
function Spells.create_tent_artifact(tile, owner)
    local visual_artifact = Battle.Artifact.new()
    local sprite = visual_artifact:sprite()
    sprite:set_texture(CHARACTER_TEXTURE)
    sprite:set_layer(-1)
    local animation = visual_artifact:get_animation()
    animation:load(character_animation)
    animation:set_state("TENT_APPEAR")
    animation:refresh(sprite)
    owner:get_field():spawn(visual_artifact, tile:x(), tile:y())
    return visual_artifact
end

---Circut hit damage
---@param user Entity
function Spells.circus_tent_hit(user, target_tile)
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(
        HitProps.new(
            user.tent_damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )

    spell.update_func = function()
        spell:get_current_tile():attack_entities(spell)
        spell:erase()
        print("Circus_hit")
    end

    spell.collision_func = function(self, other)
    end
    spell.attack_func = function(self, other)
        fx_helper.create_hit_effect(spell:get_field(),
            spell:get_current_tile(), buster_hit_texture, buster_hit_anim, "0",
            hurt_sound)
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, target_tile)
end

return Spells
